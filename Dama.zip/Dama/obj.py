import pygame
from game import WIDTH, HEIGHT  

class Obj:
    def __init__(self, image, x, y):
        raw_image = pygame.image.load(image).convert()
        self.image = pygame.transform.scale(raw_image, (WIDTH, HEIGHT))
        self.rect = self.image.get_rect(topleft=(x, y))

    def draw(self, window):
        window.blit(self.image, self.rect)