import pygame

ROWS, COLS = 8, 8
SQUARE_SIZE = 75
MARGIN = 30
WIDTH = COLS * SQUARE_SIZE + MARGIN * 2
HEIGHT = ROWS * SQUARE_SIZE + MARGIN * 2

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)
BLUE = (0, 150, 255)
DEFAULT_BOARD_COLOR = (128, 128, 128)
DEFAULT_KING_COLOR = (255, 215, 0)
VALID_MOVE_COLOR = (100, 200, 100)
SELECTED_COLOR = (0, 150, 255)

class Piece:
    def __init__(self, row, col, color, king_color=None):
        self.row = row
        self.col = col
        self.color = color
        self.king = False
        self.king_color = king_color or DEFAULT_KING_COLOR
        self.selected = False

    def make_king(self):
        self.king = True

    def draw(self, window):
        x = self.col * SQUARE_SIZE + SQUARE_SIZE // 2 + MARGIN
        y = self.row * SQUARE_SIZE + SQUARE_SIZE // 2 + MARGIN
        pygame.draw.circle(window, self.color, (x, y), 30)
        if self.king:
            pygame.draw.circle(window, self.king_color, (x, y), 15)
        if self.selected:
            pygame.draw.circle(window, SELECTED_COLOR, (x, y), 34, 4)

class Game:
    def __init__(self, p1_color=None, p2_color=None, board_color=None, king_color=None):
        self.board = [[None for _ in range(COLS)] for _ in range(ROWS)]
        self.p1_color = p1_color or RED
        self.p2_color = p2_color or BLACK
        self.board_color = board_color or DEFAULT_BOARD_COLOR
        self.king_color = king_color or DEFAULT_KING_COLOR
        self.turn = self.p1_color
        self.selected_piece = None
        self.valid_moves = {}
        self.is_capture_mandatory = False
        self.capture_moves = {}
        self.multi_jump_piece = None
        self.winner = None
        
        self.create_pieces()
        self.check_mandatory_captures()
        self.check_game_over()

    def create_pieces(self):
        for row in range(ROWS):
            for col in range(COLS):
                if (row + col) % 2 != 0:
                    if row < 3:
                        self.board[row][col] = Piece(row, col, self.p2_color, self.king_color)
                    elif row > 4:
                        self.board[row][col] = Piece(row, col, self.p1_color, self.king_color)

    def check_mandatory_captures(self):
        self.is_capture_mandatory = False
        self.capture_moves = {}

        for r in range(ROWS):
            for c in range(COLS):
                piece = self.board[r][c]
                if piece and piece.color == self.turn:
                    moves = self.get_valid_moves(piece)
                    captures = {pos: skips for pos, skips in moves.items() if skips}
                    if captures:
                        self.is_capture_mandatory = True
                        self.capture_moves[(piece.row, piece.col)] = captures
        
        if self.multi_jump_piece and (self.multi_jump_piece.row, self.multi_jump_piece.col) in self.capture_moves:
            self.is_capture_mandatory = True
            self.capture_moves = {(self.multi_jump_piece.row, self.multi_jump_piece.col): 
                                self.capture_moves[(self.multi_jump_piece.row, self.multi_jump_piece.col)]}
            self.valid_moves = self.capture_moves[(self.multi_jump_piece.row, self.multi_jump_piece.col)]
            self.selected_piece = self.multi_jump_piece
        elif self.multi_jump_piece:
            self.multi_jump_piece = None

    def _count_pieces(self):
        counts = {self.p1_color: 0, self.p2_color: 0}
        for r in range(ROWS):
            for c in range(COLS):
                piece = self.board[r][c]
                if piece:
                    counts[piece.color] += 1
        return counts

    def check_game_over(self):
        if self.winner:
            return True

        counts = self._count_pieces()

        if counts[self.p1_color] == 0:
            self.winner = self.p2_color
            return True
        if counts[self.p2_color] == 0:
            self.winner = self.p1_color
            return True

        player_can_move = False
        if self.is_capture_mandatory:
            player_can_move = bool(self.capture_moves)
        else:
            for r in range(ROWS):
                for c in range(COLS):
                    piece = self.board[r][c]
                    if piece and piece.color == self.turn and self.get_valid_moves(piece):
                        player_can_move = True
                        break
                if player_can_move:
                    break
        
        if not player_can_move and counts[self.turn] > 0:
            self.winner = self.p2_color if self.turn == self.p1_color else self.p1_color
            return True
        
        return False

    def draw_board(self, window):
        window.fill(WHITE)
        board_width = COLS * SQUARE_SIZE
        board_height = ROWS * SQUARE_SIZE
        
        pygame.draw.rect(window, BLACK, (MARGIN - 2, MARGIN - 2, board_width + 4, board_height + 4), 4)
        
        for row in range(ROWS):
            for col in range(COLS):
                color = WHITE if (row + col) % 2 == 0 else self.board_color
                pygame.draw.rect(window, color, (col * SQUARE_SIZE + MARGIN, row * SQUARE_SIZE + MARGIN, SQUARE_SIZE, SQUARE_SIZE))

        font = pygame.font.SysFont('Arial', 20)
        for col in range(COLS):
            letter = font.render(chr(ord('A') + col), True, BLACK)
            x = col * SQUARE_SIZE + MARGIN + SQUARE_SIZE // 2 - letter.get_width() // 2
            y = HEIGHT - MARGIN + (MARGIN // 2) - (letter.get_height() // 2)
            window.blit(letter, (x, y))

        for row in range(ROWS):
            number = font.render(str(ROWS - row), True, BLACK)
            y = row * SQUARE_SIZE + MARGIN + SQUARE_SIZE // 2 - number.get_height() // 2
            x = MARGIN // 2 - number.get_width() // 2
            window.blit(number, (x, y))

    def draw_valid_moves(self, window):
        for row, col in self.valid_moves:
            x = col * SQUARE_SIZE + SQUARE_SIZE // 2 + MARGIN
            y = row * SQUARE_SIZE + SQUARE_SIZE // 2 + MARGIN
            pygame.draw.circle(window, VALID_MOVE_COLOR, (x, y), 10)

    def draw_pieces(self, window):
        for row in range(ROWS):
            for col in range(COLS):
                piece = self.board[row][col]
                if piece:
                    piece.selected = (piece == self.selected_piece)
                    piece.draw(window)

    def draw(self, window):
        self.draw_board(window)
        self.draw_valid_moves(window)
        self.draw_pieces(window)
        font = pygame.font.SysFont(None, 24)
        turn_text = f"Vez do: {'Vermelho' if self.turn == self.p1_color else 'Preto'}"
        text = font.render(turn_text, True, self.turn)
        window.blit(text, (MARGIN, MARGIN // 4))
        if self.is_capture_mandatory:
            capture_text = font.render("Captura Obrigatória!", True, (255,0,0))
            window.blit(capture_text, (WIDTH - MARGIN - capture_text.get_width(), MARGIN //4))

    def handle_click(self, pos):
        x, y = pos
        if not (MARGIN <= x < WIDTH - MARGIN and MARGIN <= y < HEIGHT - MARGIN):
            if not self.multi_jump_piece:
                self.selected_piece = None
                self.valid_moves = {}
            return

        col = (x - MARGIN) // SQUARE_SIZE
        row = (y - MARGIN) // SQUARE_SIZE
        
        if self.multi_jump_piece and (row, col) in self.valid_moves:
            self.move(row, col)
            return
        
        self.select(row, col)

    def select(self, row, col):
        piece = self.board[row][col]

        if self.selected_piece:
            if (row, col) in self.valid_moves:
                self.move(row, col)
            elif piece == self.selected_piece:
                self.selected_piece = None
                self.valid_moves = {}
            elif piece and piece.color == self.turn:
                if self.is_capture_mandatory and (piece.row, piece.col) in self.capture_moves:
                    self.selected_piece = piece
                    self.valid_moves = self.capture_moves[(piece.row, piece.col)]
                elif not self.is_capture_mandatory:
                    self.selected_piece = piece
                    self.valid_moves = self.get_valid_moves(piece)
            else:
                self.selected_piece = None
                self.valid_moves = {}
        elif piece and piece.color == self.turn:
            if self.is_capture_mandatory and (piece.row, piece.col) in self.capture_moves:
                self.selected_piece = piece
                self.valid_moves = self.capture_moves[(piece.row, piece.col)]
            elif not self.is_capture_mandatory:
                self.selected_piece = piece
                self.valid_moves = self.get_valid_moves(piece)

    def move(self, row, col):
        if not self.selected_piece or (row, col) not in self.valid_moves:
            return False

        piece = self.selected_piece
        is_capture = bool(self.valid_moves[(row, col)])

        self.board[piece.row][piece.col] = None
        self.board[row][col] = piece
        
        for skip_r, skip_c in self.valid_moves[(row, col)]:
            self.board[skip_r][skip_c] = None
        
        piece.row, piece.col = row, col
        
        if (piece.color == self.p1_color and row == 0) or (piece.color == self.p2_color and row == ROWS - 1):
            piece.make_king()
        
        if is_capture:
            next_moves = self.get_valid_moves(piece)
            next_captures = {pos: skips for pos, skips in next_moves.items() if skips}
            
            if next_captures:
                self.selected_piece = piece
                self.valid_moves = next_captures
                self.multi_jump_piece = piece
                self.check_mandatory_captures()
                self.check_game_over()
                return True
            else:
                # Mantém o turno do mesmo jogador após captura
                self.multi_jump_piece = None
                self.check_mandatory_captures()
                self.check_game_over()
                return True
        else:
            self.multi_jump_piece = None
            self.change_turn()
        
        return True

    def change_turn(self):
        if self.winner:
            return

        self.turn = self.p2_color if self.turn == self.p1_color else self.p1_color
        self.selected_piece = None
        self.valid_moves = {}
        self.multi_jump_piece = None
        self.check_mandatory_captures()
        self.check_game_over()

    def get_valid_moves(self, piece):
        if piece.king:
            return self._get_king_moves(piece)
        
        moves = {}
        row = piece.row
        
        # Movimentos normais (apenas para frente)
        if piece.color == self.p1_color:  # Vermelho move para cima
            if row > 0:
                # Diagonal esquerda
                if piece.col > 0:
                    moves.update(self._check_normal_move(piece, row-1, piece.col-1))
                # Diagonal direita
                if piece.col < COLS-1:
                    moves.update(self._check_normal_move(piece, row-1, piece.col+1))
        else:  # Preto move para baixo
            if row < ROWS-1:
                # Diagonal esquerda
                if piece.col > 0:
                    moves.update(self._check_normal_move(piece, row+1, piece.col-1))
                # Diagonal direita
                if piece.col < COLS-1:
                    moves.update(self._check_normal_move(piece, row+1, piece.col+1))
        
        # Verifica capturas em todas as direções
        moves.update(self._check_capture(piece, row-1, piece.col-1, -1, -1))  # Cima-esquerda
        moves.update(self._check_capture(piece, row-1, piece.col+1, -1, 1))   # Cima-direita
        moves.update(self._check_capture(piece, row+1, piece.col-1, 1, -1))   # Baixo-esquerda
        moves.update(self._check_capture(piece, row+1, piece.col+1, 1, 1))    # Baixo-direita
        
        # Se houver capturas obrigatórias, filtra apenas elas
        if self.is_capture_mandatory:
            return {pos: skips for pos, skips in moves.items() if skips}
        
        return moves

    def _check_normal_move(self, piece, row, col):
        """Verifica movimento normal (sem captura)"""
        if self.board[row][col] is None:
            return {(row, col): []}
        return {}

    def _check_capture(self, piece, row, col, row_dir, col_dir):
        """Verifica possíveis capturas em uma direção"""
        moves = {}
        
        # Verifica se está dentro do tabuleiro
        if not (0 <= row < ROWS and 0 <= col < COLS):
            return moves
        
        target = self.board[row][col]
        
        # Se houver uma peça adversária
        if target and target.color != piece.color:
            # Verifica a casa após a peça adversária
            jump_row = row + row_dir
            jump_col = col + col_dir
            
            if 0 <= jump_row < ROWS and 0 <= jump_col < COLS:
                if self.board[jump_row][jump_col] is None:
                    moves[(jump_row, jump_col)] = [(row, col)]
        
        return moves

    def _get_king_moves(self, piece):
        moves = {}
        directions = [(-1, -1), (-1, 1), (1, -1), (1, 1)] 
        
        for dr, dc in directions:
            r, c = piece.row, piece.col
            skipped = []

            while True:
                r += dr
                c += dc

                if not (0 <= r < ROWS and 0 <= c < COLS):
                    break

                square = self.board[r][c]

                if square is None:
                    if skipped:
                        moves[(r, c)] = list(skipped) 
                        break
                    else:
                        moves[(r, c)] = []
                elif square.color == piece.color:
                    break
                else:
                    if skipped: 
                        break
                    else:
                        skipped.append((r, c))
        return moves