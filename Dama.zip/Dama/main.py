import pygame
from menu import Menu
from obj import Obj
from game import Game, WIDTH, HEIGHT, RED, BLACK

class Main:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Jogo de Damas")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.menu = Menu()
        self.game = Game()
        self.running = True
        self.state = "menu"
        self.victory_screens = {
            RED: "assets/vitoria_vermelho.png",
            BLACK: "assets/vitoria_preto.png"
        }

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            if self.state == "menu":
                self.menu.event(event)
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN and self.menu.change_scene:
                        self.state = "game"
                        self.menu.change_scene = False
                        self.game = Game()
            
            elif self.state == "game":
                if not self.game.winner:
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        self.game.handle_click(event.pos)
                    elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                        self.state = "menu"
                        self.menu.index = 0
                        self.menu.bg = Obj(self.menu.screens[self.menu.index], 0, 0)
                else:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RETURN:
                            self.state = "menu"
                            self.menu.index = 0
                            self.menu.bg = Obj(self.menu.screens[self.menu.index], 0, 0)
                        elif event.key == pygame.K_ESCAPE:
                            pygame.event.post(pygame.event.Event(pygame.QUIT))

    def draw(self):
        if self.state == "menu":
            self.menu.draw(self.screen)
        elif self.state == "game":
            self.game.draw(self.screen)
            if self.game.winner:
                self.draw_victory_screen()
        pygame.display.update()

    def draw_victory_screen(self):
        # Carrega a tela de vitória apropriada
        winner_screen = Obj(self.victory_screens[self.game.winner], 0, 0)
        winner_screen.draw(self.screen)

    def run(self):
        while self.running:
            self.clock.tick(60)
            self.events()
            self.draw()
        pygame.quit()

if __name__ == "__main__":
    main_app = Main()
    main_app.run()