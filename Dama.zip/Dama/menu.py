import pygame
from obj import Obj

class Menu:
    def __init__(self):
        self.screens = ["assets/inicio.png", "assets/menu.png", "assets/regras.png"]
        self.index = 0
        self.bg = Obj(self.screens[self.index], 0, 0)
        self.change_scene = False

    def draw(self, window):
        self.bg.draw(window)

    def event(self, event):
        if event.type == pygame.KEYDOWN:
            if self.index == 0:  # Tela inicial
                if event.key == pygame.K_RETURN:
                    self.index = 1
                    self.bg = Obj(self.screens[self.index], 0, 0)
            
            elif self.index == 1:  # Menu principal
                if event.key == pygame.K_RETURN:
                    self.change_scene = True
                elif event.key == pygame.K_r:
                    self.index = 2  # Ir para regras
                    self.bg = Obj(self.screens[self.index], 0, 0)
                elif event.key == pygame.K_ESCAPE:
                    pygame.event.post(pygame.event.Event(pygame.QUIT))
            
            elif self.index == 2:  # Tela de regras
                if event.key == pygame.K_ESCAPE:
                    self.index = 1  # Voltar para menu
                    self.bg = Obj(self.screens[self.index], 0, 0)